// @name: LS Static Actor Finder
// @version: v0.23
// @author: Jakob Tischler, 2012
// @desc: to find possible static actor error sources in an i3d map file

## LS Static Actor Finder ##
============================

Durch das herunterladen dieser Zip-Datei stimmen Sie folgenden Bedingungen zu:

1.	Die Zip-Datei und deren Inhalte d�rfen nirgendwo weiterverbreitet werden. Nur der Originalautor (Jakob Tischler) has das Verbreitungsrecht.
2.	Die beinhalteten Dateien d�rfen nicht ver�ndert und daraufhin weiterverbreitet werden.
3.	Der Autor haftet nicht f�r jedwege Sch�den die durch das Programm erscheinen.
4.	Viel Spa�.
	
