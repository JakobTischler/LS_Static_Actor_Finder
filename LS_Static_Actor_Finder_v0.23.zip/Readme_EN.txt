// @name: LS Static Actor Finder
// @version: v0.23
// @author: Jakob Tischler, 2012
// @desc: to find possible static actor error sources in an i3d map file

## LS Static Actor Finder ##
============================

By downloading this zip file you agree to the following terms:

1.	You may not distribute neither the zip file nor the included files anywhere. Only the original author (Jakob Tischler) has the right of distribution.
2.	You may not alter any of the included files and re-distribute them anywhere.
3.	The author will not be held accountable for any possible damage caused by this tool.
4.	You better enjoy this!
	
